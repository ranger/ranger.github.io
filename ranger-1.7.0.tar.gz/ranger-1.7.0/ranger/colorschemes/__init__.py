"""Colorschemes are required to be located here or in CONFDIR/colorschemes/"""
