"""Default options and configration files"""
