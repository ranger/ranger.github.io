from ranger.gui.displayable import Displayable

class Widget(Displayable):
    """A class for classification of widgets."""
